# Authors, Citation, and License

## Intended Use

**This app is intended for research purposes only and is not for clinical use.** Do not use it for patient diagnosis, treatment, surgical planning, or other clinical decisions.

## Authors

**3D Atlas of Neurological Surgery** is the author of **3D Anatomical Morphometry**, an app for 3D model measurement, anatomical analysis, and neurosurgical corridor evaluation.

[Visit the 3D Atlas of Neurological Surgery website](https://3datlasofneurologicalsurgery.org/index.php).

## How to Cite

**If you use 3D Anatomical Morphometry, you must cite 3D Atlas of Neurological Surgery in any publication, presentation, report, or other shared work that uses the app or its results.** Include the citation in the references, methods, acknowledgments, or figure caption, as appropriate.

**Suggested citation**

> 3D Atlas of Neurological Surgery. *3D Anatomical Morphometry* (Version 0.1.0) [Computer software].

Use the version you actually ran if it differs from the example. This is the project's citation policy and is separate from the terms of the MIT License.

## MIT License

Copyright (c) 2026 3D Atlas of Neurological Surgery

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
