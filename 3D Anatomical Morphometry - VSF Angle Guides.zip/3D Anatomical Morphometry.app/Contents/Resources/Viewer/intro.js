(() => {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const viewer = document.getElementById('root');
  const intro = document.createElement('div');
  intro.className = 'morph-intro';
  intro.setAttribute('role', 'region');
  intro.setAttribute('aria-label', 'App introduction');
  intro.innerHTML = `
    <div class="morph-intro__content" aria-hidden="true">
      <svg class="morph-intro__corridor" viewBox="0 0 380 228" fill="none">
        <path class="morph-intro__grid" d="M39 49H341M39 81H341M39 113H341M39 145H341M39 177H341M72 29V199M104 29V199M136 29V199M168 29V199M200 29V199M232 29V199M264 29V199M296 29V199M328 29V199"/>
        <g class="morph-intro__faces">
          <path d="M62 103L134 51L306 47L257 82Z" fill="#5eead4" fill-opacity=".13"/>
          <path d="M134 51L178 147L339 111L306 47Z" fill="#5eead4" fill-opacity=".27"/>
          <path d="M178 147L104 202L288 150L339 111Z" fill="#2dd4bf" fill-opacity=".13"/>
          <path d="M62 103L134 51L178 147L104 202Z" fill="#3b82f6" fill-opacity=".43"/>
          <path d="M257 82L306 47L339 111L288 150Z" fill="#fb7185" fill-opacity=".47"/>
        </g>
        <path class="morph-intro__draw morph-intro__entry" pathLength="1" d="M62 103L134 51L178 147L104 202Z" stroke="#7dd3fc"/>
        <path class="morph-intro__draw morph-intro__edges" pathLength="1" d="M62 103L257 82M134 51L306 47M178 147L339 111M104 202L288 150" stroke="#5eead4"/>
        <path class="morph-intro__draw morph-intro__target" pathLength="1" d="M257 82L306 47L339 111L288 150Z" stroke="#fda4af"/>
        <path class="morph-intro__axis" d="M122 126L299 98" stroke="#b9f7ed" stroke-dasharray="3 6"/>
        <g class="morph-intro__nodes">
          <path d="M62 103h.01M134 51h.01M178 147h.01M104 202h.01" stroke="#d4f2ff"/>
          <path d="M257 82h.01M306 47h.01M339 111h.01M288 150h.01" stroke="#ffe4e6"/>
        </g>
      </svg>
      <div class="morph-intro__title">3D Anatomical Morphometry</div>
      <div class="morph-intro__credit">3D Atlas of Neurological Surgery</div>
    </div>
    <button type="button" class="morph-intro__skip">Skip intro</button>
  `;

  const previousInert = viewer?.inert;
  if (viewer) viewer.inert = true;
  document.body.append(intro);
  const timeout = window.setTimeout(dismiss, 4300);

  function dismiss() {
    window.clearTimeout(timeout);
    document.removeEventListener('keydown', onKey);
    intro.remove();
    if (viewer) viewer.inert = previousInert;
  }

  function onKey(event) {
    if (event.key === 'Escape') dismiss();
  }

  intro.querySelector('button').addEventListener('click', dismiss);
  intro.addEventListener('animationend', event => {
    if (event.target === intro && event.animationName === 'morph-intro-exit') dismiss();
  });
  document.addEventListener('keydown', onKey);
})();
